package com.example.Explorer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
