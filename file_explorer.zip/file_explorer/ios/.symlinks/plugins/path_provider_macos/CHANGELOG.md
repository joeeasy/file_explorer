## 0.0.4+3

* Remove Android folder from `path_provider_macos`.

## 0.0.4+2

* Declare API stability and compatibility with `1.0.0` (more details at: https://github.com/flutter/flutter/wiki/Package-migration-to-1.0.0).

## 0.0.4+1

* Fix CocoaPods podspec lint warnings.

## 0.0.4

* Adds an example app to run integration tests.

## 0.0.3+1

* Make the pedantic dev_dependency explicit.

## 0.0.3

* Added support for user's downloads directory.

## 0.0.2+1

* Update README.

## 0.0.1

* Initial open source release.
