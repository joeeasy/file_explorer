import 'package:stacked/stacked.dart';

class SearchBarViewModel extends BaseViewModel {

}